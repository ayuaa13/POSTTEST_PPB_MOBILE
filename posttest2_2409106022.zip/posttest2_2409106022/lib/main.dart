import 'package:flutter/material.dart';
import 'cartPage.dart';
import 'widgets/productCard.dart';

void main() {
  runApp(const WonkaStoreApp());
}

class WonkaStoreApp extends StatelessWidget {
  const WonkaStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WonkaStore - Posttest 3',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4A148C)),
      ),
      home: const MainScreen(),
    );
  }
}

// ----------------------------------------------------
// MainScreen diubah menjadi StatefulWidget untuk mengatur Tab
// ----------------------------------------------------
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  // Menyimpan posisi tab yang sedang aktif
  int _selectedIndex = 0;

  // Daftar halaman yang akan diganti-ganti di dalam body
  final List<Widget> _pages = [
    const HomeContent(), // Index 0: Beranda
    const CartPage(),    // Index 1: Keranjang (Sekarang menyatu dengan MainScreen)
    const Center(child: Text('Halaman Profil', style: TextStyle(color: Colors.white, fontSize: 20))), // Index 2: Profil
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2A0845),

      // Layar akan berubah sesuai tab yang ditekan
      body: _pages[_selectedIndex],

      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF1E0533),
        indicatorColor: const Color(0xFFFFD700).withOpacity(0.3),
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) {
          // Mengganti tampilan tab tanpa harus pindah (push) halaman
          setState(() {
            _selectedIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.home, color: Colors.white54),
              selectedIcon: Icon(Icons.home, color: Color(0xFFFFD700)),
              label: 'Beranda'
          ),
          NavigationDestination(
              icon: Icon(Icons.shopping_cart, color: Colors.white54),
              selectedIcon: Icon(Icons.shopping_cart, color: Color(0xFFFFD700)),
              label: 'Keranjang'
          ),
          NavigationDestination(
              icon: Icon(Icons.person, color: Colors.white54),
              selectedIcon: Icon(Icons.person, color: Color(0xFFFFD700)),
              label: 'Profil'
          ),
        ],
      ),
    );
  }
}


class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Selamat Datang di', style: TextStyle(color: Colors.white70, fontSize: 16)),
                const SizedBox(height: 4),
                const Text('WonkaStore ✨', style: TextStyle(color: Color(0xFFFFD700), fontSize: 28, fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                Container(
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Cari keajaiban cokelat...',
                      hintStyle: TextStyle(color: Colors.grey.shade400),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.all(16),
                      suffixIcon: Padding(
                        padding: const EdgeInsets.only(right: 16),
                        child: Icon(Icons.search, size: 24, color: const Color(0xFF4A148C)),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Katalog Spesial', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 16),
                  ProductCard(title: 'Hoverchoc', desc: 'Membuatmu bisa melayang.', price: 'Rp 55.000'),
                  SizedBox(height: 16),
                  ProductCard(title: 'Silver Lining', desc: 'Memberi secercah harapan.', price: 'Rp 65.000'),
                  SizedBox(height: 16),
                  ProductCard(title: 'Big Night Out', desc: 'Sensasi malam di perkotaan.', price: 'Rp 85.000'),
                  SizedBox(height: 16),
                  ProductCard(title: 'The Wonka Bar', desc: 'Cokelat klasik peninggalan ibu.', price: 'Rp 150.000'),
                  SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}