import 'package:flutter/material.dart';

class CartProductCard extends StatelessWidget {
  final String title;
  final String price;

  const CartProductCard({super.key, required this.title, required this.price});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFD700),
        border: Border.all(color: const Color(0xFFB8860B), width: 2),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          // Image.asset
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset(
              'assets/product.png',
              width: 70,
              height: 70,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(width: 70, height: 70, color: const Color(0xFF4E342E), child: const Icon(Icons.cookie, color: Colors.white54, size: 30)),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF3E2723))),
                const SizedBox(height: 6),
                Text(price, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: Color(0xFF1B5E20))),
              ],
            ),
          ),
          const SizedBox(width: 12),

          // Input Jumlah Barang
          Container(
            width: 45,
            height: 45,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFB8860B)),
            ),
            child: TextField(
              textAlign: TextAlign.center,
              // keyboardType TextInputType.number
              keyboardType: TextInputType.number,
              style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF3E2723)),
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintText: '1',
                hintStyle: TextStyle(color: Colors.grey),
              ),
            ),
          )
        ],
      ),
    );
  }
}