import 'package:flutter/material.dart';
import 'widgets/cartProductCard.dart';

class CartPage extends StatelessWidget {
  const CartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2A0845),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E0533),
        title: const Text('Keranjang Sihir', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold)),
        automaticallyImplyLeading: false,
      ),

      body: SafeArea(
        //Stack
        child: Stack(
          children: [
            SingleChildScrollView(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 120),
              child: Column(
                children: const [
                  CartProductCard(title: 'Hoverchoc', price: 'Rp 55.000'),
                  SizedBox(height: 16),
                  CartProductCard(title: 'The Wonka Bar', price: 'Rp 150.000'),
                  SizedBox(height: 16),
                  CartProductCard(title: 'Silver Lining', price: 'Rp 65.000'),
                ],
              ),
            ),

            // Positioned
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFD700),
                  borderRadius: const BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
                  // BoxShadow
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.6),
                      blurRadius: 15,
                      offset: const Offset(0, -5),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Total Sihir', style: TextStyle(fontSize: 14, color: Color(0xFF5D4037), fontWeight: FontWeight.bold)),
                          SizedBox(height: 4),
                          Text('Rp 270.000', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20))),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          // Navigator.push
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const SuccessPage()),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF3E2723),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.shopping_cart_checkout, color: Color(0xFFFFD700), size: 20),
                            SizedBox(width: 8),
                            Text('Checkout', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 16)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class SuccessPage extends StatelessWidget {
  const SuccessPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2A0845),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, color: Color(0xFFFFD700), size: 100),
            const SizedBox(height: 24),
            const Text(
              'Pembayaran Sihir Berhasil!',
              style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                // Navigator.pop
                // Kembali ke halaman keranjang
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFD700),
                foregroundColor: const Color(0xFF3E2723),
              ),
              child: const Text('Kembali ke Keranjang', style: TextStyle(fontWeight: FontWeight.bold)),
            )
          ],
        ),
      ),
    );
  }
}