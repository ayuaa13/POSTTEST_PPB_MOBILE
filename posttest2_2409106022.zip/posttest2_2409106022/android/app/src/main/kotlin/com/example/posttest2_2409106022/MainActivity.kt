package com.example.posttest2_2409106022

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
