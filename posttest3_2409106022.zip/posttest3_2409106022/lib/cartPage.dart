import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'widgets/cartProductCard.dart';
import 'providers/cart_provider.dart';

class CartPage extends StatelessWidget {
  const CartPage({super.key});

  @override
  Widget build(BuildContext context) {
    // KONSEP STATE DILUAR MODUL: context.watch
    final cart = context.watch<CartProvider>();

    return Scaffold(
      backgroundColor: const Color(0xFF2A0845),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E0533),
        title: const Text('Keranjang Sihir', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold)),
        automaticallyImplyLeading: false,
      ),

      body: SafeArea(
        child: Stack(
          children: [
            SingleChildScrollView(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 120),
              child: Column(
                children: cart.items.isEmpty
                    ? [const Center(child: Text("Keranjang kosong, beli cokelat dulu yuk!", style: TextStyle(color: Colors.white)))]
                    : cart.items.map((item) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: CartProductCard(
                      title: item['title'],
                      price: item['price'],
                      qty: item['qty'],
                      image: item['image'],
                    ),
                  );
                }).toList(),
              ),
            ),

            Positioned(
              left: 0, right: 0, bottom: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFD700),
                  borderRadius: const BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 15, offset: const Offset(0, -5))],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Total Sihir', style: TextStyle(fontSize: 14, color: Color(0xFF5D4037), fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text('Rp ${cart.totalPrice}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20))),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: cart.items.isEmpty ? null : () {
                          // WIDGET LANJUTAN MODUL 3: Navigator.push
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const SuccessPage()),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF3E2723),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: const Text('Checkout', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 16)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// HALAMAN SUKSES (Untuk Memenuhi Syarat Navigator.pop Modul 3)
class SuccessPage extends StatelessWidget {
  const SuccessPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2A0845),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, color: Color(0xFFFFD700), size: 100),
            const SizedBox(height: 24),
            const Text(
              'Pembayaran Berhasil!',
              style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                // WIDGET LANJUTAN MODUL 3: Navigator.pop
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFD700),
                foregroundColor: const Color(0xFF3E2723),
              ),
              child: const Text('Kembali ke Keranjang', style: TextStyle(fontWeight: FontWeight.bold)),
            )
          ],
        ),
      ),
    );
  }
}