import 'package:flutter/material.dart';

// KONSEP STATE DILUAR MODUL: Provider (ChangeNotifier)
class CartProvider extends ChangeNotifier {
  final List<Map<String, dynamic>> _items = [];

  List<Map<String, dynamic>> get items => _items;

  // Menyimpan image bersamaan dengan title dan price
  void addToCart(String title, int price, String image) {
    int index = _items.indexWhere((item) => item['title'] == title);
    if (index >= 0) {
      _items[index]['qty'] += 1;
    } else {
      _items.add({
        'title': title,
        'price': price,
        'qty': 1,
        'image': image // Menerima data gambar
      });
    }
    notifyListeners();
  }

  void updateQuantity(String title, int newQty) {
    int index = _items.indexWhere((item) => item['title'] == title);
    if (index >= 0) {
      if (newQty <= 0) {
        _items.removeAt(index);
      } else {
        _items[index]['qty'] = newQty;
      }
      notifyListeners();
    }
  }

  int get totalPrice {
    int total = 0;
    for (var item in _items) {
      total += (item['price'] as int) * (item['qty'] as int);
    }
    return total;
  }
}