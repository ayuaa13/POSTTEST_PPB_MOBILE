import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cartPage.dart';
import 'widgets/productCard.dart';
import 'providers/cart_provider.dart';

void main() {
  runApp(
    // KONSEP STATE DILUAR MODUL: ChangeNotifierProvider
    ChangeNotifierProvider(
      create: (context) => CartProvider(),
      child: const WonkaStoreApp(),
    ),
  );
}

class WonkaStoreApp extends StatelessWidget {
  const WonkaStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WonkaStore',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4A148C)),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const HomeContent(),
    const CartPage(),
    const Center(child: Text('Halaman Profil', style: TextStyle(color: Colors.white, fontSize: 20))),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2A0845),
      body: _pages[_selectedIndex],
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF1E0533),
        indicatorColor: const Color(0xFFFFD700).withValues(alpha: 0.3),
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home, color: Colors.white54), selectedIcon: Icon(Icons.home, color: Color(0xFFFFD700)), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.shopping_cart, color: Colors.white54), selectedIcon: Icon(Icons.shopping_cart, color: Color(0xFFFFD700)), label: 'Keranjang'),
          NavigationDestination(icon: Icon(Icons.person, color: Colors.white54), selectedIcon: Icon(Icons.person, color: Color(0xFFFFD700)), label: 'Profil'),
        ],
      ),
    );
  }
}

class HomeContent extends StatefulWidget {
  const HomeContent({super.key});
  @override
  State<HomeContent> createState() => _HomeContentState();
}

class _HomeContentState extends State<HomeContent> {
  // KONSEP STATE MODUL 4: Menyimpan keyword pencarian
  String searchQuery = '';

  // Data 8 Produk Wonka Lengkap dengan Gambarnya
  final List<Map<String, dynamic>> wonkaProducts = [
    {'title': 'The Wonka Bar', 'desc': 'Cokelat klasik berbalut kertas buatan tangan. Peninggalan ibu.', 'price': 150000, 'image': 'assets/wonka_bar.jpeg'},
    {'title': 'Silver Lining', 'desc': 'Awan badai & sinar matahari cair. Memberi secercah harapan.', 'price': 65000, 'image': 'assets/silver_lining.jpeg'},
    {'title': 'Hair Repair Éclair', 'desc': 'Campuran keringat Yeti untuk menumbuhkan rambut lebat.', 'price': 120000, 'image': 'assets/hair_repair.jpeg'},
    {'title': 'Big Night Out', 'desc': 'Sensasi malam di perkotaan dalam satu gigitan truffle mewah.', 'price': 85000, 'image': 'assets/big_night_out.jpeg'},
    {'title': 'Acacia Mint', 'desc': 'Permen mint khusus kesukaan Abigail sang jerapah.', 'price': 35000, 'image': 'assets/acacia_mint.jpeg'},
    {'title': 'Giraffe Milk Macaroon', 'desc': 'Susu jerapah distilasi. Rasakan sensasi menjadi yang paling tinggi.', 'price': 70000, 'image': 'assets/giraffe_milk.jpeg'},
    {'title': 'Forty Second Sweet', 'desc': 'Seketika membuatmu bernyanyi & menari ala Broadway.', 'price': 45000, 'image': 'assets/forty_second.jpeg'},
    {'title': 'Hoverchoc', 'desc': 'Karamel asin dengan hover-fly, membuatmu bisa melayang.', 'price': 55000, 'image': 'assets/hoverchoc.jpeg'},
  ];

  @override
  Widget build(BuildContext context) {
    // Filter produk berdasarkan teks pencarian
    final filteredProducts = wonkaProducts.where((product) {
      return product['title'].toString().toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();

    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Selamat Datang di', style: TextStyle(color: Colors.white70, fontSize: 16)),
                const Text('WonkaStore ✨', style: TextStyle(color: Color(0xFFFFD700), fontSize: 28, fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                Container(
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: TextField(
                    // KONSEP STATE MODUL 4: TextField (onChanged)
                    onChanged: (value) {
                      setState(() {
                        searchQuery = value;
                      });
                    },
                    decoration: InputDecoration(
                      hintText: 'Cari keajaiban cokelat...',
                      hintStyle: TextStyle(color: Colors.grey.shade400),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.all(16),
                      suffixIcon: Padding(
                        padding: const EdgeInsets.only(right: 16),
                        child: Icon(Icons.search, size: 24, color: const Color(0xFF4A148C)),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Katalog Spesial', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),

                  // Me-render kartu produk
                  ...filteredProducts.map((product) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 16.0),
                      child: ProductCard(
                        title: product['title'],
                        desc: product['desc'],
                        price: product['price'],
                        image: product['image'],
                      ),
                    );
                  }),

                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}