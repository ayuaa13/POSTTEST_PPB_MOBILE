import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';

class ProductCard extends StatelessWidget {
  final String title;
  final String desc;
  final int price;
  final String image;

  const ProductCard({
    super.key,
    required this.title,
    required this.desc,
    required this.price,
    required this.image,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFD700),
        border: Border.all(color: const Color(0xFFB8860B), width: 2),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.asset(image, width: 85, height: 100, fit: BoxFit.cover, errorBuilder: (c, e, s) => Container(width: 85, height: 100, color: const Color(0xFF4E342E))),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF3E2723))),
                const SizedBox(height: 6),
                Text(desc, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Color(0xFF5D4037))),
                const SizedBox(height: 8),
                Text('Rp $price', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: Color(0xFF1B5E20))),
                const SizedBox(height: 12),

                // KONSEP STATE MODUL 4: State ElevatedButton
                ElevatedButton(
                  onPressed: () {
                    // Mengirimkan image ke provider juga
                    context.read<CartProvider>().addToCart(title, price, image);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('$title masuk keranjang!'), duration: const Duration(seconds: 1)),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF3E2723),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.add_shopping_cart, color: Color(0xFFFFD700), size: 16),
                      SizedBox(width: 8),
                      Text('Beli Cokelat', style: TextStyle(color: Color(0xFFFFD700), fontSize: 12, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}