package com.example.posttest3_2409106022

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
