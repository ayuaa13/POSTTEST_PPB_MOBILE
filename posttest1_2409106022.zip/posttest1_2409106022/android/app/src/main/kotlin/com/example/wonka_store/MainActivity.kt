package com.example.wonka_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
