import 'package:flutter/material.dart';

void main() {
  runApp(const WonkaStoreApp());
}

class WonkaStoreApp extends StatelessWidget {
  const WonkaStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WonkaStore',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4A148C)),
      ),
      home: const HomePage(), // Memanggil HomePage yang statis
    );
  }
}

// Halaman utama dikembalikan menjadi StatelessWidget
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2A0845),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Selamat Datang di',
                style: TextStyle(color: Colors.white70, fontSize: 16),
              ),
              const SizedBox(height: 4),
              const Text(
                'WonkaStore ✨',
                style: TextStyle(
                  color: Color(0xFFFFD700),
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),

              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Cari keajaiban cokelat...',
                    hintStyle: TextStyle(color: Colors.grey.shade400),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.all(16),
                    suffixIcon: Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: Icon(
                        Icons.search,
                        size: 24,
                        color: const Color(0xFF4A148C),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 32),

              const Text(
                'Katalog Spesial',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),

              _buildProductCard('Hoverchoc', 'Karamel asin dengan hover-fly, membuatmu bisa melayang di udara.', 'Rp 55.000'),
              const SizedBox(height: 16),
              _buildProductCard('Silver Lining', 'Awan badai & sinar matahari cair. Memberi secercah harapan.', 'Rp 65.000'),
              const SizedBox(height: 16),
              _buildProductCard('Big Night Out', 'Sensasi malam di perkotaan dalam satu gigitan truffle mewah.', 'Rp 85.000'),
              const SizedBox(height: 16),
              _buildProductCard('Forty Second Sweet', 'Seketika membuatmu bernyanyi & menari ala Broadway.', 'Rp 45.000'),
              const SizedBox(height: 16),
              _buildProductCard('Hair Repair Éclair', 'Campuran keringat Yeti untuk menumbuhkan rambut lebat.', 'Rp 120.000'),
              const SizedBox(height: 16),
              _buildProductCard('Giraffe Milk Macaroon', 'Susu jerapah distilasi. Rasakan sensasi menjadi yang paling tinggi.', 'Rp 70.000'),
              const SizedBox(height: 16),
              _buildProductCard('Acacia Mint', 'Permen mint khusus kesukaan Abigail sang jerapah.', 'Rp 35.000'),
              const SizedBox(height: 16),
              _buildProductCard('The Wonka Bar', 'Cokelat klasik berbalut kertas buatan tangan. Peninggalan ibu.', 'Rp 150.000'),
            ],
          ),
        ),
      ),

      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF1E0533),
        selectedItemColor: const Color(0xFFFFD700),
        unselectedItemColor: Colors.white54,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Beranda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart), // Ikon keranjang statis, tanpa angka (Badge)
            label: 'Keranjang',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }

  Widget _buildProductCard(String title, String description, String price) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFD700),
        border: Border.all(color: const Color(0xFFB8860B), width: 2),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 85,
            height: 100,
            decoration: BoxDecoration(
              color: const Color(0xFF4E342E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(
              child: Icon(Icons.cookie, color: Colors.white54, size: 40),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Color(0xFF3E2723),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11, color: Color(0xFF5D4037)),
                ),
                const SizedBox(height: 8),
                Text(
                  price,
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    color: Color(0xFF1B5E20),
                  ),
                ),
                const SizedBox(height: 12),

                // Tombol Beli Cokelat Statis (tanpa GestureDetector)
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF3E2723),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.add_shopping_cart, color: Color(0xFFFFD700), size: 16),
                      SizedBox(width: 8),
                      Text(
                        'Beli Cokelat',
                        style: TextStyle(color: Color(0xFFFFD700), fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}